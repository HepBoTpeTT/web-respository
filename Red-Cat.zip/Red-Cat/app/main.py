from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .models import Base, Application
from .admin_panel import setup_admin  # 👈 новое
from pydantic import BaseModel

SQLALCHEMY_DATABASE_URL = "sqlite:///./database.db"

engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base.metadata.create_all(bind=engine)

app = FastAPI()

class NoCacheStaticFiles(StaticFiles):
    async def get_response(self, path, scope):
        response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response

app.mount("/static", NoCacheStaticFiles(directory="frontend"), name="static")

@app.get("/", response_class=HTMLResponse)
async def index():
    with open("frontend/index.html", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())
    
# подключение админки
@app.on_event("startup")
async def startup():
    await setup_admin(app)

class ApplicationCreate(BaseModel):
    name: str
    ceiling_area: int
    phone: str

@app.post("/apply")
async def create_application(application: ApplicationCreate):
    db = SessionLocal()
    new_app = Application(
        name=application.name,
        ceiling_area=application.ceiling_area,
        phone=application.phone
    )
    try:
        db.add(new_app)
        db.commit()
        return {"message": "Заявка успешно сохранена"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()
