# admin_panel.py
from fastapi_admin.app import app as admin_app
from fastapi_admin.providers.login import UsernamePasswordProvider
from fastapi_admin.resources import Model
from starlette.requests import Request
from models import Application
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine
from fastapi_admin.factory import app as create_admin_app
import os

DATABASE_URL = "sqlite+aiosqlite:///./database.db"

class ApplicationResource(Model):
    label = "Заявки"
    model = Application

async def setup_admin(app):
    engine: AsyncEngine = create_async_engine(DATABASE_URL, echo=True)
    await admin_app.configure(
        logo_url="https://fastapi.tiangolo.com/img/logo-margin/logo-teal.png",
        template_folders=[],
        providers=[
            UsernamePasswordProvider(
                admin_model=None,
                login_logo_url="https://fastapi.tiangolo.com/img/logo-margin/logo-teal.png",
            )
        ],
        admin_path="/admin",
        engine=engine,
        resources=[
            ApplicationResource,
        ],
    )
    app.mount("/admin", admin_app)
